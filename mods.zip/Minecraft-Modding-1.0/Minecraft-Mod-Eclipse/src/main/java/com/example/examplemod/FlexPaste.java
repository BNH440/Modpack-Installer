package com.example.examplemod;

import net.minecraft.block.material.Material;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class FlexPaste extends Item {
	public FlexPaste() {
		this.setRegistryName("flex_paste");
	    this.setUnlocalizedName("flex_paste");
	    this.setCreativeTab(CreativeTabs.MATERIALS);
		// TODO Auto-generated constructor stub
	}
}
