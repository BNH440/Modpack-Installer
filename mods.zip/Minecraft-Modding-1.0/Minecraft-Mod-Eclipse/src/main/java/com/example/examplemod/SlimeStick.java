package com.example.examplemod;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class SlimeStick extends Item {
	public SlimeStick() {
		this.setRegistryName("slime_stick");
	    this.setUnlocalizedName("slime_stick");
	    this.setCreativeTab(CreativeTabs.MATERIALS);
		// TODO Auto-generated constructor stub
	}
}
